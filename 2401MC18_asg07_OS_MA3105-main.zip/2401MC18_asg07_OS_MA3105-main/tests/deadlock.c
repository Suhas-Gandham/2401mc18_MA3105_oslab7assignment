#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define P 5
#define R 3

int avail[R];
int alloc[P][R];
int req[P][R];

static void
clearall(void)
{
  int i, j;
  for (j = 0; j < R; j++) avail[j] = 0;
  for (i = 0; i < P; i++)
    for (j = 0; j < R; j++) { alloc[i][j] = 0; req[i][j] = 0; }
}

// Banker-style detection: work=Available; processes whose request
// can be satisfied finish and release; leftovers are deadlocked.
static int
detect(int dead[P])
{
  int work[R], finish[P];
  int i, j, changed, ok, nd;
  for (j = 0; j < R; j++) work[j] = avail[j];
  for (i = 0; i < P; i++) {
    finish[i] = 1;
    for (j = 0; j < R; j++)
      if (alloc[i][j] != 0) finish[i] = 0;
    dead[i] = 0;
  }
  changed = 1;
  while (changed) {
    changed = 0;
    for (i = 0; i < P; i++) {
      if (finish[i]) continue;
      ok = 1;
      for (j = 0; j < R; j++)
        if (req[i][j] > work[j]) ok = 0;
      if (ok) {
        for (j = 0; j < R; j++) work[j] += alloc[i][j];
        finish[i] = 1;
        changed = 1;
      }
    }
  }
  nd = 0;
  for (i = 0; i < P; i++)
    if (!finish[i]) { dead[i] = 1; nd++; }
  return nd;
}

static void
report(int nd, int dead[P])
{
  int i;
  if (nd == 0) {
    printf("No deadlock.\n");
  } else {
    for (i = 0; i < P; i++)
      if (dead[i]) printf("Deadlocked process: P%d\n", i);
    printf("Deadlock detected!\n");
  }
}

int
main(void)
{
  int dead[P];

  printf("=== Deadlock Detection (Q3) ===\n\n");

  printf("Test 1: Safe state\n");
  clearall();
  avail[0]=2; avail[1]=2; avail[2]=2;
  alloc[0][0]=1; alloc[1][1]=1;
  req[0][0]=1;  req[1][1]=1;
  report(detect(dead), dead);
  printf("\n");

  printf("Test 2: Deadlocked state (circular wait)\n");
  clearall();
  avail[0]=0; avail[1]=0; avail[2]=0;
  alloc[0][0]=1; alloc[1][1]=1; alloc[2][2]=1; alloc[3][0]=1; alloc[4][1]=1;
  req[0][1]=1;  req[1][2]=1;  req[2][0]=1;  req[3][2]=1;  req[4][0]=1;
  report(detect(dead), dead);
  printf("\n");

  printf("Test 3: Dynamic resource requests\n");
  clearall();
  avail[0]=2; avail[1]=2; avail[2]=2;
  alloc[0][0]=1; alloc[0][1]=1; alloc[1][1]=1; alloc[1][2]=1;
  req[0][0]=1; req[0][1]=0; req[0][2]=1;
  req[1][0]=1; req[1][1]=0; req[1][2]=0;
  printf("  Phase 1 (initial requests): ");
  report(detect(dead), dead);
  avail[0]=0; avail[1]=1; avail[2]=0;
  alloc[0][0]=2; alloc[0][1]=1; alloc[0][2]=2;
  alloc[1][0]=1; alloc[1][1]=2; alloc[1][2]=1;
  req[0][0]=1; req[0][1]=1; req[0][2]=1;
  req[1][0]=1; req[1][1]=0; req[1][2]=1;
  printf("  Phase 2 (after P0 and P1 request more): ");
  report(detect(dead), dead);
  printf("\n");

  printf("Test 4: Recovery by aborting a deadlocked process\n");
  printf("  Aborting P1 and releasing its resources...\n");
  for (int j = 0; j < R; j++) {
    avail[j] += alloc[1][j];
    alloc[1][j] = 0;
    req[1][j] = 0;
  }
  printf("  After recovery: ");
  report(detect(dead), dead);

  exit(0);
}
